---
layout: page
title: langcodes/README
---
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />

script.module.langcodes
=======================

A repackaging of **langcodes**, **langcode_data** and **marisa_trie** into one kodi addon

See LICENSE files in the directories with the package name.

Author of maria-trie: Susumu Yata <susumu.yata@gmail.com>
[Project](https://github.com/s-yata/marisa-trie)

Author of langcodes, language_data: Robyn Speer <rspeer@arborelia.net>
[Project](https://github.com/rspeer/langcodes)

NOTE: this addon is not yet in the repository. Must download and install the [repository .zip file](http://smeagol/repo/zipsURL_LANGCODES_ZIP.LANGCODES_ZIP_VERSION).
