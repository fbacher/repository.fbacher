# coding=utf-8

# from common.typing import *
# from common.settings import Settings
# from backends.base import BaseEngineService
# from backends.backend_index import BootstrapEngines
# from backends.backend_info import BackendInfo

# import xbmc

# xbmc.log('Running BackendInfo.init', xbmc.LOGINFO)
# BackendInfo.init()
