# coding=utf-8
from __future__ import annotations  # For union operator |

from common import *


class IConverter:

    @staticmethod
    def register() -> None:
        pass  # Overridden
