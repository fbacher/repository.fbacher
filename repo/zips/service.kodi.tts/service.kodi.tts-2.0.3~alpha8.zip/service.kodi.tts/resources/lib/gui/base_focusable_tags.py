# coding=utf-8

"""
onfocus 	Specifies the built-in function that should be executed when the control is
focussed.

onunfocus 	Specifies the built-in function that should be executed when the control is
loses focus.
"""
